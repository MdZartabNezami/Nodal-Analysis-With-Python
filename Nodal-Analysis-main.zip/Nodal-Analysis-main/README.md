# Nodal-Analysis 
Designed a program that takes the required well data and gives the bottom hole pressure and flow rate in which that well should operate
Operational Point is obtained using linear IPR model and Poettmann–Carpenter’s TPR model
